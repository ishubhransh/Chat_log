const       express         =       require('express');
const       app             =       express();
const       router          =       express.Router();
const       HomeController  =       require('../controller/home_controller');


router.get('/chatlogs/:user',HomeController.homeGet);
router.post('/chatlogs/:user',HomeController.homePost);
router.delete('/chatlogs/:user',HomeController.homeDel);
router.delete('/chatlogs/:user/:msg',HomeController.homeSpDel);


module.exports=router;