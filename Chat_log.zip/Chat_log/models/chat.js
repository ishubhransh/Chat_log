var mongoose = require('mongoose');  
var chatSchema = new mongoose.Schema({  
  message: {
    type:String,
    required:true
  },
  isCompleted: {
    type:Boolean,
    default:true
  }
  },{
      timestamps:true
  });
mongoose.model('chat', chatSchema);

module.exports=mongoose.model("chat",chatSchema);