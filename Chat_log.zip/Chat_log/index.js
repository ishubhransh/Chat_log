const       express         =       require('express');
const       app             =       express();
const       router          =       require('./routes/home');
const       port            =       8000;
const       bodyParser      =       require('body-parser');
const       db              =       require('./config/mongoose');
const       chat            =       require('./models/chat');
// parse application/json
app.use(bodyParser.json());
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));

app.use('/',router);

app.listen(port,function(err){
    if(err)
        console.log(`Error: ${err}`);
    else{
        console.log(`Server is Running on Port:${port}`);
    }
});
