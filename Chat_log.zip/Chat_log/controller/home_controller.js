var chat = require('../models/chat');
const querystring = require('querystring');
var url = require('url');

module.exports.homeGet = function (req, res) {
    var url_parts = url.parse(req.url, true);
    var query = url_parts.query;
    chat.find({}, function (err, data) {
        if (err)
            console.log(`There is an Error in fetching entries from Database. ${err}`);
        else {
            console.log(query);
            // console.log("hfghg",querystring.parse(query));
            res.send(data);
        }
    });


}


module.exports.homePost = function (req, res) {
    console.log(req.body);
    chat.create({
        message: req.body.message,
        isCompleted: true
    }, function (err, data) {
        if (err) {
            console.log(`There is an Error in creating a new entry in Database. ${err}`);
        }
        else {
            res.send({
                MessageId: data._id
            });
        }

    })
};


module.exports.homeDel = function (req, res) {
    var myData;
    chat.find({}, function (err, data) {
        if (err)
            console.log(`There is an Error in fetching entries from Database. ${err}`);
        else {
            for (const property in data) {
                chat.findByIdAndDelete(data[property]._id, function (err, docs) {
                    if (err) {
                        console.log(`There is an Error ${err}`);
                    }
                    else {
                        return res.send('All deteted');
                    }
                });
            }
        }
    });

};




module.exports.homeSpDel = function (req, res) {
    var myData=req.params.msg;

                chat.findByIdAndRemove(myData,function(err){
                    if(err){
                        console.log(err);
                    }
                    else{
                       return res.send(`Deleted ${myData}`);
                    }
                });
};